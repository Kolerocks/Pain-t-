package application;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;

public class Stack {
	private int maxSize;
	private Image[] stackA;
	private int top;
	

	public Stack() {
		maxSize = 1000;
		top = -1;
		stackA = new Image[maxSize];
	}
	
	// Saves the image onto the stack
		public int push(Canvas canvas) {
			WritableImage im = canvas.snapshot(null, null);
			/*try {
				ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", file);
			} catch (IOException e) {
				e.printStackTrace();
			}*/
			stackA[++top] = im;
			if (stackA[top] == im) {
				return 0;
			} else {
				return 1;
			}
		}

		// Pulls the 2nd latest image saved
		public Image pull() {
			return stackA[top--];
		}

		// Peeks at the top of the stack
		public Image peek() {
			return stackA[top];
		}

		public boolean isEmpty() {
			return top == -1;
		}

		public boolean isFull() {
			return top == maxSize - 1;
		}
}
