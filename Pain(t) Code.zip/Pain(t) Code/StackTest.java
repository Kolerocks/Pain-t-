package application;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import javafx.scene.canvas.Canvas;

class StackTest {

	@Test
	void testPeek() {
		Canvas canvas = new Canvas(100, 100);
		Canvas canvas2 = new Canvas(100, 100);
		Stack stackUndo;
		stackUndo = new Stack();
		stackUndo.push(canvas);
		stackUndo.push(canvas2);
		assertNotNull(stackUndo.peek());
	}
	
	@Test
	void testPull() {
		Canvas canvas = new Canvas(100, 100);
		Canvas canvas2 = new Canvas(100, 100);
		Stack stackUndo;
		stackUndo = new Stack();
		stackUndo.push(canvas);
		stackUndo.push(canvas2);
		assertNotNull(stackUndo.pull());
	}
	
	@Test
	void testPush() {
		Canvas canvas = new Canvas(100, 100);
		Canvas canvas2 = new Canvas(100, 100);
		Stack stackUndo;
		stackUndo = new Stack();
		stackUndo.push(canvas);
		stackUndo.push(canvas2);
		assertEquals(stackUndo.push(canvas), 1);
	}

}
