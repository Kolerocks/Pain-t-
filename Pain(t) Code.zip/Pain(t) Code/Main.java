package application;

import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Timer;
import java.util.TimerTask;

import javax.imageio.ImageIO;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Toggle;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Font;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.input.KeyEvent;

public class Main extends Application {

	// Intializes layouts, scene, file, image, and other variables
	StackPane stackPane;
	Button close1;
	Button saveAs;
	Button load;
	Button save;
	Button help;
	Button doubleClose;
	Button doubleSave;
	Button rect;
	Button zoomI;
	Button undo;
	Button zoomO;
	Button onA;
	Button offA;
	Button redo;
	Button textGo;
	Button applyD;
	Button saveConfirm;
	Button saveCancel;
	Button newTab;
	Button copy;
	Button paste;
	Image image1;
	Image imagec;
	File file;
	Label space;
	Label auto;
	Label helpT;
	Label warn;
	Label smartL;
	Label text;
	Label drag;
	Label tabName;
	TextField tName;
	TextField textF;
	TextField textX;
	TextField textY;
	TextField sides;
	TextField pX;
	TextField pY;
	TextField dX;
	TextField dY;
	double rectX;
	double rectY;
	double rectXF;
	double rectYF;

	private double[] xCoord, yCoord;
	private int pointCt;
	private boolean complete;

	WritableImage w2;

	Stack stackUndo;
	Stack stackRedo;

	// Timer variables
	Timer timer = new Timer();
	int onoff = 1;
	int autosave_state = 0;
	
	// Tab count
	int t;
	
	@Override
	public void start(Stage stage) {
		// set title for the stage
		stage.setTitle("Pain(t)");
		stage.initStyle(StageStyle.TRANSPARENT);

		stackUndo = new Stack();
		stackRedo = new Stack();

		// Assigns values to each button and label
		close1 = new Button("Close");
		saveAs = new Button("Save File As");
		load = new Button(" Load ");
		save = new Button("Save File");
		help = new Button(" Help ");
		rect = new Button("Rectangle");
		zoomI = new Button("Zoom In");
		zoomO = new Button(" Zoom Out ");
		saveConfirm = new Button("Confirm");
		saveCancel = new Button("Cancel");
		doubleSave = new Button("Save");
		doubleClose = new Button("Close");
		onA = new Button("On");
		offA = new Button("Off");
		applyD = new Button("Apply Drag");
		copy = new Button("Copy");
		paste = new Button("Paste");
		space = new Label("");
		tabName = new Label("Name:");
		undo = new Button("Undo");
		redo = new Button("Redo");
		newTab = new Button("New Tab");
		auto = new Label("Autosave: off");
		text = new Label("Enter [text] [x] [Y]");
		drag = new Label("Drag Pos [x] [Y]");
		tName = new TextField();
		textF = new TextField();
		textX = new TextField();
		textY = new TextField();
		sides = new TextField();
		pX = new TextField();
		pY = new TextField();
		dX = new TextField();
		dY = new TextField();
		textGo = new Button("Apply Text");

		// Names the toggle buttons
		ToggleButton pencil = new ToggleButton("Pencil");
		ToggleButton pen = new ToggleButton("    Pen    ");
		ToggleButton square = new ToggleButton(" Square ");
		ToggleButton rectangle = new ToggleButton(" Rectangle ");
		ToggleButton ellipse = new ToggleButton(" Oval ");
		ToggleButton circle = new ToggleButton("Circle");
		ToggleButton grabber = new ToggleButton("Dropper");
		ToggleButton eraser = new ToggleButton("Eraser");
		ToggleButton mover = new ToggleButton("Mover");
		ToggleButton drect = new ToggleButton("Double Rect");
		ToggleButton poly = new ToggleButton("Draw a polygon");

		// Creates the intial canvas and grid
		final Canvas canvas = new Canvas(1, 1);
		GridPane grid = new GridPane();
		//GridPane tabGrid = new GridPane();
		final Canvas canvasI = new Canvas(100, 100);
		
		// Adds tabs
		TabPane tabPane = new TabPane();
        Tab tab1 = new Tab("First Tab", new Label(""));
        tabPane.getTabs().add(tab1);

		// Adds the buttons and labels to the grid
		grid.setHgap(20);
		grid.setVgap(5);
		grid.add(close1, 3, 0);
		grid.add(saveAs, 2, 0);
		grid.add(load, 0, 0);
		grid.add(save, 1, 0);
		grid.add(help, 0, 1);
		grid.add(zoomI, 1, 1);
		grid.add(zoomO, 2, 1);
		grid.add(undo, 3, 1);
		grid.add(redo, 4, 1);
		grid.add(grabber, 5, 1);
		grid.add(pencil, 0, 2);
		grid.add(pen, 1, 2);
		grid.add(square, 3, 2);
		grid.add(rectangle, 2, 2);
		grid.add(ellipse, 4, 2);
		grid.add(circle, 5, 2);
		grid.add(mover, 0, 3);
		grid.add(eraser, 1, 3);
		grid.add(drect, 6, 2);
		grid.add(text, 0, 5);
		grid.add(textF, 1, 5);
		grid.add(textX, 2, 5);
		grid.add(textY, 3, 5);
		grid.add(textGo, 4, 5);
		grid.add(dX, 1, 6);
		grid.add(dY, 2, 6);
		grid.add(drag, 0, 6);
		grid.add(poly, 0, 7);
		grid.add(auto, 1, 7);
		grid.add(onA, 2, 7);
		grid.add(offA, 3, 7);
		//Grid.setVgap(200);
		//Grid.setHgap(5);
		grid.add(newTab, 4, 7);
		grid.add(tabName, 5, 7);
		grid.add(tName, 6, 7);
		grid.add(copy, 0, 8);
		grid.add(paste, 1, 8);
		grid.add(tabPane, 8, 8);
		

		// Creates a slider and adds it too the grid
		Slider slider = new Slider(0, 100, 0);
		grid.add(slider, 6, 0);

		SingleSelectionModel<Tab> selectionModel = tabPane.getSelectionModel();
		
		// Creates grid spacing
		grid.getColumnConstraints().add(new ColumnConstraints(100));
		grid.getColumnConstraints().add(new ColumnConstraints(100));
		grid.getColumnConstraints().add(new ColumnConstraints(100));
		grid.getColumnConstraints().add(new ColumnConstraints(100));
		grid.getColumnConstraints().add(new ColumnConstraints(100));
		grid.getColumnConstraints().add(new ColumnConstraints(100));
		grid.getColumnConstraints().add(new ColumnConstraints(100));
		grid.getColumnConstraints().add(new ColumnConstraints(100));

		// Assigns variables
		xCoord = new double[500];
		yCoord = new double[500];
		pointCt = 0;

		// Creates the graphicsContext
		GraphicsContext graphicsContext = canvasI.getGraphicsContext2D();
		tab1.setContent(canvasI);
		int size = 100;

		// Creates the color chooser and places it in grid
		TilePane r = new TilePane();
		ColorPicker cp = new ColorPicker();
		r.getChildren().add(cp);
		grid.add(r, 7, 0);

		// Resizes image/canvas and makes it smaller
		newTab.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				Tab tab = new Tab(tName.getText(), new Label(""));
				tabPane.getTabs().add(tab);
			}
		});

		// Sets up the toggle buttons
		final ToggleGroup group = new ToggleGroup();
		pencil.setToggleGroup(group);
		pencil.setStyle("-fx-base: lightgreen;");
		pen.setToggleGroup(group);
		pen.setStyle("-fx-base: lightgreen;");
		square.setToggleGroup(group);
		square.setStyle("-fx-base: lightgreen;");
		rectangle.setToggleGroup(group);
		rectangle.setStyle("-fx-base: lightgreen;");
		ellipse.setToggleGroup(group);
		ellipse.setStyle("-fx-base: lightgreen;");
		circle.setToggleGroup(group);
		circle.setStyle("-fx-base: lightgreen;");
		grabber.setToggleGroup(group);
		grabber.setStyle("-fx-base: lightblue;");
		mover.setToggleGroup(group);
		mover.setStyle("-fx-base: red;");
		eraser.setToggleGroup(group);
		eraser.setStyle("-fx-base: red;");
		drect.setToggleGroup(group);
		drect.setStyle("-fx-base: lightgreen;");
		poly.setToggleGroup(group);
		poly.setStyle("-fx-base: orange;");

		// Draws a straight line when the pen button is toggled
		ChangeListener<Toggle> poly2 = new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle toggle, Toggle new_toggle) {
				canvasI.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						// Prepares the polygon
						stackUndo.push(canvasI);
						if (!poly.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_PRESSED, this);
						} else {
							if (complete) {
								complete = false;
								xCoord[0] = event.getX();
								yCoord[0] = event.getY();
								pointCt = 1;
							}
							// Checks if the polygon is complete
							else if (pointCt > 0 && pointCt > 0 && (Math.abs(xCoord[0] - event.getX()) <= 3)
									&& (Math.abs(yCoord[0] - event.getY()) <= 3)) {
								complete = true;
							} else {
								// Add the points where the user clicked
								xCoord[pointCt] = event.getX();
								yCoord[pointCt] = event.getY();
								pointCt++;
							}
							// Draws the polygon
							draw(canvasI, cp.getValue());
						}
					}
				});

				// Adds paint to the canvas where the mouse is released
				canvasI.addEventHandler(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						if (!poly.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_RELEASED, this);
						} else {
							double width = slider.getValue();
							graphicsContext.setStroke(Color.TRANSPARENT);
							graphicsContext.setLineWidth(width);
							graphicsContext.lineTo(event.getX(), event.getY());
							graphicsContext.stroke();
							graphicsContext.closePath();
						}
					}
				});
			}
		};

		// Creates an action when the load button is pressed
		textGo.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				if ((textF.getText() != null && !textF.getText().isEmpty())) {
					GraphicsContext gc = canvasI.getGraphicsContext2D();
					gc.setStroke(cp.getValue());
					int x = Integer.parseInt(textX.getText());
					int y = Integer.parseInt(textY.getText());
					gc.strokeText(textF.getText(), x, y);
				} else {
				}
			}
		});

		// Copies the canvas as an image
		copy.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				WritableImage im = canvas.snapshot(null, null);
				imagec = im;
			}
		});

		// Pastes the copied image
		paste.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				//canvasL = new Canvas(image1.getWidth(), image1.getHeight());
				GraphicsContext graphicsContext2 = canvasI.getGraphicsContext2D();
				graphicsContext2.drawImage(imagec, 0, 0);
				ScrollPane scrollPane2 = new ScrollPane();
				scrollPane2.setVbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane2.setHbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane2.setContent(canvasI);
				StackPane stack_pane3 = new StackPane(scrollPane2);			   	
				int current = 0;
				current = tabPane.getSelectionModel().getSelectedIndex();
				selectionModel.select(current);
				selectionModel.getSelectedItem().setContent(stack_pane3);
			}
		});

		// Draws where the mouse is when the pencil button is toggled
		ChangeListener<Toggle> mover2 = new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle toggle, Toggle new_toggle) {
				// Assigns the values to graphicsContext
				graphicsContext.setStroke(Color.WHITE);
				graphicsContext.setLineWidth(10);
				graphicsContext.setFill(cp.getValue());
				Image image2 = canvasI.snapshot(null, null);

				canvasI.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						// Creates the origin and prepares for the select and drag
						if (!mover.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_PRESSED, this);
						} else {
							Group group = new Group();
							graphicsContext.beginPath();
							rectX = event.getX();
							rectY = event.getY();
						}
					}
				});

				// Shows the area being dragged and writes the selected area
				canvasI.addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						if (!mover.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_DRAGGED, this);
						} else {
							graphicsContext.setStroke(Color.WHITE);
							graphicsContext.setLineWidth(10);
							graphicsContext.setFill(Color.BLUE);
							graphicsContext.setGlobalAlpha(0.01);
							// For each of the following draws the rectangle and grabs that part of the
							// image
							// If X left Y up
							if (event.getX() < rectX && event.getY() < rectY) {
								graphicsContext.fillRect(event.getX(), event.getY(), rectX - event.getX(),
										rectY - event.getY());
								Image pi = canvas.snapshot(null, null);
								final PixelReader pr = image1.getPixelReader();
								WritableImage w3 = new WritableImage(pr, (int) event.getX(), (int) event.getY(),
										(int) (rectX - event.getX()), (int) (rectY - event.getY()));
								w2 = w3;
								graphicsContext.setFill(Color.WHITE);
								graphicsContext.fillRect(event.getX(), event.getY(), rectX - event.getX(),
										rectY - event.getY());
								rectXF = event.getX();
								rectYF = event.getY();
							}
							// If X left Y down
							if (event.getX() < rectX && event.getY() > rectY) {
								graphicsContext.fillRect(event.getX(), rectY, rectX - event.getX(),
										event.getY() - rectY);
								Image pi = canvas.snapshot(null, null);
								final PixelReader pr = image1.getPixelReader();
								WritableImage w3 = new WritableImage(pr, (int) event.getX(), (int) rectY,
										(int) (rectX - event.getX()), (int) (event.getY() - rectY));
								w2 = w3;
								graphicsContext.setFill(Color.WHITE);
								graphicsContext.fillRect(event.getX(), rectY, rectX - event.getX(),
										event.getY() - rectY);
								rectXF = event.getX();
								rectYF = event.getY();
							}
							// If X right Y up
							if (event.getX() > rectX && event.getY() < rectY) {
								graphicsContext.fillRect(rectX, event.getY(), event.getX() - rectX,
										rectY - event.getY());
								Image pi = canvas.snapshot(null, null);
								final PixelReader pr = image1.getPixelReader();
								WritableImage w3 = new WritableImage(pr, (int) rectX, (int) event.getY(),
										(int) (event.getX() - rectX), (int) (rectY - event.getY()));
								w2 = w3;
								graphicsContext.setFill(Color.WHITE);
								graphicsContext.fillRect(rectX, event.getY(), event.getX() - rectX,
										rectY - event.getY());
								rectXF = event.getX();
								rectYF = event.getY();
							}
							// If X right Y down
							if (event.getX() > rectX && event.getY() > rectY) {
								graphicsContext.fillRect(rectX, rectY, event.getX() - rectX, event.getY() - rectY);
								Image pi = canvas.snapshot(null, null);
								final PixelReader pr = image1.getPixelReader();
								WritableImage w3 = new WritableImage(pr, (int) rectX, (int) rectY,
										(int) (event.getX() - rectX), (int) (event.getY() - rectY));
								w2 = w3;
								graphicsContext.setFill(Color.WHITE);
								graphicsContext.fillRect(rectX, rectY, event.getX() - rectX, event.getY() - rectY);
								rectXF = event.getX();
								rectYF = event.getY();
							}

						}
					}
				});

				canvasI.addEventHandler(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						if (!mover.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_RELEASED, this);
						} else {
							graphicsContext.setGlobalAlpha(1);
							graphicsContext.setFill(Color.WHITE);

							// Makes sure the position is not empty
							if (dX.getText() == "" || dY.getText() == "") {
								return;
							}

							// Moves the selected area
							// X left Y up
							if (rectXF < rectX && rectYF < rectY) {
								graphicsContext.fillRect(rectXF, rectYF, rectX - rectXF, rectY - rectYF);
								GraphicsContext graphicsContext = canvasI.getGraphicsContext2D();
								graphicsContext.drawImage(w2, Integer.parseInt(dX.getText()),
										Integer.parseInt(dY.getText()), rectX - rectXF, rectY - rectYF);
							}
							// X left Y down
							if (rectXF < rectX && rectYF > rectY) {
								graphicsContext.fillRect(rectXF, rectY, rectX - rectXF, rectYF - rectY);
								GraphicsContext graphicsContext = canvasI.getGraphicsContext2D();
								graphicsContext.drawImage(w2, Integer.parseInt(dX.getText()),
										Integer.parseInt(dY.getText()), rectX - rectXF, rectYF - rectY);
							}
							// X right Y up
							if (rectXF > rectX && rectYF < rectY) {
								graphicsContext.fillRect(rectX, rectYF, rectXF - rectX, rectY - rectYF);
								GraphicsContext graphicsContext = canvasI.getGraphicsContext2D();
								graphicsContext.drawImage(w2, Integer.parseInt(dX.getText()),
										Integer.parseInt(dY.getText()), rectXF - rectX, rectY - rectYF);
							}
							// X right Y down
							if (rectXF > rectX && rectYF > rectY) {
								graphicsContext.fillRect(rectX, rectY, rectXF - rectX, rectYF - rectY);
								GraphicsContext graphicsContext = canvasI.getGraphicsContext2D();
								graphicsContext.drawImage(w2, Integer.parseInt(dX.getText()),
										Integer.parseInt(dY.getText()), rectXF - rectX, rectYF - rectY);
							}

							// Creates scroll bars
							ScrollPane scrollPane = new ScrollPane();
							scrollPane.setVbarPolicy(ScrollBarPolicy.ALWAYS);
							scrollPane.setHbarPolicy(ScrollBarPolicy.ALWAYS);

							// Adds the components together onto one scene
							scrollPane.setContent(canvasI);
							StackPane stack_pane2 = new StackPane(scrollPane);
							grid.add(stack_pane2, 8, 8);

							// Create a scene
							Scene scene2 = new Scene(grid, 1, 1);

							// Sets and launches the scene
							stage.setScene(scene2);
							stage.show();

							stackUndo.push(canvasI);
						}
					}
				});
			}
		};

		// Draws a straight line when the pen button is toggled
		ChangeListener<Toggle> pen2 = new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle toggle, Toggle new_toggle) {
				canvasI.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						stackUndo.push(canvasI);
						if (!pen.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_PRESSED, this);
						} else {
							double width = slider.getValue();
							graphicsContext.setStroke(cp.getValue());
							graphicsContext.setLineWidth(width);
							graphicsContext.beginPath();
							graphicsContext.moveTo(event.getX(), event.getY());
							graphicsContext.stroke();
						}
					}
				});

				// Adds paint to the canvas where the mouse is released
				canvasI.addEventHandler(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						// push(canvasI);
						if (!pen.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_RELEASED, this);
						} else {
							double width = slider.getValue();
							graphicsContext.setStroke(cp.getValue());
							graphicsContext.setLineWidth(width);
							graphicsContext.lineTo(event.getX(), event.getY());
							graphicsContext.stroke();
							graphicsContext.closePath();
						}
					}
				});
			}
		};

		// Draws where the mouse is when the pencil button is toggled
		ChangeListener<Toggle> pencil2 = new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle toggle, Toggle new_toggle) {
				canvasI.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						stackUndo.push(canvasI);
						if (!pencil.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_PRESSED, this);
						} else {
							double width = slider.getValue();
							graphicsContext.setStroke(cp.getValue());
							graphicsContext.setLineWidth(width);
							graphicsContext.beginPath();
							graphicsContext.moveTo(event.getX(), event.getY());
							graphicsContext.stroke();
						}

					}
				});

				// Adds paint to the canvas where the mouse is dragged
				canvasI.addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						// push(canvasI);
						if (!pencil.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_DRAGGED, this);
						} else {
							double width = slider.getValue();
							graphicsContext.setLineWidth(width);
							graphicsContext.setStroke(cp.getValue());
							// graphicsContext.fillRoundRect(event.getX(), event.getY(), (double) 1,
							// (double) 1, (double) 1);
							graphicsContext.fillRect(event.getX(), event.getY(), 1, 1);
							graphicsContext.lineTo(event.getX(), event.getY());
							graphicsContext.stroke();
							graphicsContext.closePath();
							graphicsContext.beginPath();
							graphicsContext.moveTo(event.getX(), event.getY());
							System.out.print(cp.getValue());
						}
					}

				});

				// Adds paint to the canvas where the mouse is released
				canvasI.addEventHandler(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						// push(canvasI);
						if (!pencil.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_RELEASED, this);
						} else {
							double width = slider.getValue();
							graphicsContext.setStroke(cp.getValue());
							graphicsContext.setLineWidth(width);
							graphicsContext.lineTo(event.getX(), event.getY());
							graphicsContext.stroke();
							graphicsContext.closePath();
						}
					}
				});
			}
		};

		// Draws a rectangle when the rectangle button is toggled
		ChangeListener<Toggle> rectangle2 = new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle toggle, Toggle new_toggle) {
				graphicsContext.setStroke(cp.getValue());
				graphicsContext.setFill(cp.getValue());

				canvasI.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {

						if (!rectangle.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_PRESSED, this);
						} else {
							graphicsContext.beginPath();
							rectX = event.getX();
							rectY = event.getY();
							stackUndo.push(canvasI);
						}
					}
				});

				// Adds paint to the canvas where the mouse is dragged
				canvasI.addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						if (!rectangle.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_DRAGGED, this);
						} else {
							image1 = stackUndo.peek();
							graphicsContext.drawImage(image1, 0, 0);
							graphicsContext.setStroke(cp.getValue());
							graphicsContext.setFill(cp.getValue());
							// X left Y up
							if (event.getX() < rectX && event.getY() < rectY) {
								graphicsContext.fillRect(event.getX(), event.getY(), rectX - event.getX(),
										rectY - event.getY());
							}
							// X left Y down
							if (event.getX() < rectX && event.getY() > rectY) {
								graphicsContext.fillRect(event.getX(), rectY, rectX - event.getX(),
										event.getY() - rectY);
							}
							// X right Y up
							if (event.getX() > rectX && event.getY() < rectY) {
								graphicsContext.fillRect(rectX, event.getY(), event.getX() - rectX,
										rectY - event.getY());
							}
							// X right Y down
							if (event.getX() > rectX && event.getY() > rectY) {
								graphicsContext.fillRect(rectX, rectY, event.getX() - rectX, event.getY() - rectY);
							}
						}
					}
				});
			}
		};

		// Draws a diybke rectangle when the rectangle button is toggled
		ChangeListener<Toggle> drect2 = new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle toggle, Toggle new_toggle) {
				graphicsContext.setStroke(cp.getValue());
				graphicsContext.setFill(cp.getValue());
				canvasI.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						if (!drect.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_PRESSED, this);
						} else {
							graphicsContext.beginPath();
							rectX = event.getX();
							rectY = event.getY();
							stackUndo.push(canvasI);
						}
					}
				});

				// Adds paint to the canvas where the mouse is dragged
				canvasI.addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						if (!drect.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_DRAGGED, this);
						} else {
							image1 = stackUndo.peek();
							graphicsContext.drawImage(image1, 0, 0);
							graphicsContext.setStroke(cp.getValue());
							graphicsContext.setFill(cp.getValue());
							// X left Y up
							if (event.getX() < rectX && event.getY() < rectY) {
								graphicsContext.fillRect(event.getX(), event.getY(), rectX - event.getX(),
										rectY - event.getY());
								graphicsContext.fillRect(2 * event.getX(), 2 * event.getY(), rectX - event.getX(),
										rectY - event.getY());
							}
							// X left Y down
							if (event.getX() < rectX && event.getY() > rectY) {
								graphicsContext.fillRect(event.getX(), rectY, rectX - event.getX(),
										event.getY() - rectY);
								graphicsContext.fillRect(2 * event.getX(), 2 * rectY, rectX - event.getX(),
										event.getY() - rectY);
							}
							// X right Y up
							if (event.getX() > rectX && event.getY() < rectY) {
								graphicsContext.fillRect(rectX, event.getY(), event.getX() - rectX,
										rectY - event.getY());
								graphicsContext.fillRect(2 * rectX, 2 * event.getY(), event.getX() - rectX,
										rectY - event.getY());
							}
							// X right Y down
							if (event.getX() > rectX && event.getY() > rectY) {
								graphicsContext.fillRect(rectX, rectY, event.getX() - rectX, event.getY() - rectY);
								graphicsContext.fillRect(2 * rectX, 2 * rectY, event.getX() - rectX,
										event.getY() - rectY);
							}
						}
					}
				});
			}
		};

		// Draws a square when the square button is toggled
		ChangeListener<Toggle> square2 = new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle toggle, Toggle new_toggle) {
				graphicsContext.setStroke(cp.getValue());
				graphicsContext.setFill(cp.getValue());
				canvasI.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						stackUndo.push(canvasI);
						if (!square.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_PRESSED, this);
						} else {
							graphicsContext.beginPath();
							rectX = event.getX();
							rectY = event.getY();
							stackUndo.push(canvasI);
						}
					}
				});

				// Adds paint to the canvas where the mouse is released
				canvasI.addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						if (!square.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_DRAGGED, this);
						} else {
							image1 = stackUndo.peek();
							graphicsContext.drawImage(image1, 0, 0);
							graphicsContext.setStroke(cp.getValue());
							graphicsContext.setFill(cp.getValue());
							// X left Y up
							if (event.getX() < rectX && event.getY() < rectY) {
								graphicsContext.fillRect(rectX - (rectY - event.getY()), event.getY(),
										rectY - event.getY(), rectY - event.getY());
							}
							// X left Y down
							if (event.getX() < rectX && event.getY() > rectY) {
								graphicsContext.fillRect(event.getX(), rectY, rectX - event.getX(),
										rectX - event.getX());
							}
							// X right Y up
							if (event.getX() > rectX && event.getY() < rectY) {
								graphicsContext.fillRect(rectX, event.getY(), rectY - event.getY(),
										rectY - event.getY());
							}
							// X right Y down
							if (event.getX() > rectX && event.getY() > rectY) {
								graphicsContext.fillRect(rectX, rectY, event.getX() - rectX, event.getX() - rectX);
							}

						}
					}
				});
			}
		};

		// Draws a ellipse when the ellipse button is toggled
		ChangeListener<Toggle> ellipse2 = new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle toggle, Toggle new_toggle) {
				graphicsContext.setStroke(cp.getValue());
				graphicsContext.setFill(cp.getValue());
				canvasI.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						stackUndo.push(canvasI);
						if (!ellipse.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_PRESSED, this);
						} else {
							graphicsContext.beginPath();
							rectX = event.getX();
							rectY = event.getY();
							stackUndo.push(canvasI);
						}
					}
				});

				// Adds paint to the canvas where the mouse is released
				canvasI.addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						if (!ellipse.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_DRAGGED, this);
						} else {
							image1 = stackUndo.peek();
							graphicsContext.drawImage(image1, 0, 0);
							graphicsContext.setStroke(cp.getValue());
							graphicsContext.setFill(cp.getValue());
							// X left Y up
							if (event.getX() < rectX && event.getY() < rectY) {
								graphicsContext.fillOval(event.getX(), event.getY(), rectX - event.getX(),
										rectY - event.getY());
							}
							// X left Y down
							if (event.getX() < rectX && event.getY() > rectY) {
								graphicsContext.fillOval(event.getX(), rectY, rectX - event.getX(),
										event.getY() - rectY);
							}
							// X right Y up
							if (event.getX() > rectX && event.getY() < rectY) {
								graphicsContext.fillOval(rectX, event.getY(), event.getX() - rectX,
										rectY - event.getY());
							}
							// X right Y down
							if (event.getX() > rectX && event.getY() > rectY) {
								graphicsContext.fillOval(rectX, rectY, event.getX() - rectX, event.getY() - rectY);
							}
						}
					}
				});
			}
		};

		// Draws a circle when the circle button is toggled
		ChangeListener<Toggle> circle2 = new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle toggle, Toggle new_toggle) {
				graphicsContext.setStroke(cp.getValue());
				graphicsContext.setFill(cp.getValue());
				canvasI.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						stackUndo.push(canvasI);
						if (!circle.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_PRESSED, this);
						} else {
							graphicsContext.beginPath();
							rectX = event.getX();
							rectY = event.getY();
							stackUndo.push(canvasI);
						}
					}
				});

				// Adds paint to the canvas where the mouse is released
				canvasI.addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						if (!circle.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_DRAGGED, this);
						} else {
							image1 = stackUndo.peek();
							graphicsContext.drawImage(image1, 0, 0);
							graphicsContext.setStroke(cp.getValue());
							graphicsContext.setFill(cp.getValue());
							// X left Y up
							if (event.getX() < rectX && event.getY() < rectY) {
								graphicsContext.fillOval(rectX - (rectY - event.getY()), event.getY(),
										rectY - event.getY(), rectY - event.getY());
							}
							// X left Y down
							if (event.getX() < rectX && event.getY() > rectY) {
								graphicsContext.fillOval(event.getX(), rectY, rectX - event.getX(),
										rectX - event.getX());
							}
							// X right Y up
							if (event.getX() > rectX && event.getY() < rectY) {
								graphicsContext.fillOval(rectX, event.getY(), rectY - event.getY(),
										rectY - event.getY());
							}
							// X right Y down
							if (event.getX() > rectX && event.getY() > rectY) {
								graphicsContext.fillOval(rectX, rectY, event.getX() - rectX, event.getX() - rectX);
							}
						}
					}
				});
			}
		};

		// Grabs the color of the pixel when the dropper button is toggled
		ChangeListener<Toggle> dropper = new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle toggle, Toggle new_toggle) {
				graphicsContext.setStroke(cp.getValue());
				graphicsContext.setFill(cp.getValue());
				canvasI.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						if (!grabber.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_PRESSED, this);
						} else {
							final PixelReader pr = image1.getPixelReader();
							if (pr == null) {
							} else {
								cp.setValue(pr.getColor((int) event.getX(), (int) event.getY()));
							}
						}
					}
				});
			}
		};

		// Draws where the mouse and erases
		ChangeListener<Toggle> eraser2 = new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle toggle, Toggle new_toggle) {
				canvasI.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						stackUndo.push(canvasI);
						if (!eraser.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_PRESSED, this);
						} else {
							double width = slider.getValue();
							graphicsContext.setStroke(Color.WHITE);
							graphicsContext.setLineWidth(width);
							graphicsContext.beginPath();
							graphicsContext.moveTo(event.getX(), event.getY());
							graphicsContext.stroke();
						}
					}
				});

				// Adds paint to the canvas where the mouse is dragged
				canvasI.addEventHandler(MouseEvent.MOUSE_DRAGGED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						// push(canvasI);
						if (!eraser.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_DRAGGED, this);
						} else {
							double width = slider.getValue();
							graphicsContext.setLineWidth(width);
							graphicsContext.setStroke(Color.WHITE);
							// graphicsContext.fillRoundRect(event.getX(), event.getY(), (double) 1,
							// (double) 1, (double) 1);
							graphicsContext.fillRect(event.getX(), event.getY(), 1, 1);
							graphicsContext.lineTo(event.getX(), event.getY());
							graphicsContext.stroke();
							graphicsContext.closePath();
							graphicsContext.beginPath();
							graphicsContext.moveTo(event.getX(), event.getY());
							System.out.print(cp.getValue());
						}
					}
				});

				// Adds paint to the canvas where the mouse is released
				canvasI.addEventHandler(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						// push(canvasI);
						if (!eraser.isSelected()) {
							canvasI.removeEventHandler(MouseEvent.MOUSE_RELEASED, this);
						} else {
							double width = slider.getValue();
							graphicsContext.setStroke(Color.WHITE);
							graphicsContext.setLineWidth(width);
							graphicsContext.lineTo(event.getX(), event.getY());
							graphicsContext.stroke();
							graphicsContext.closePath();
						}
					}
				});
			}
		};

		// Adds the toggle buttons into a group
		group.selectedToggleProperty().addListener(pencil2);
		group.selectedToggleProperty().addListener(pen2);
		group.selectedToggleProperty().addListener(rectangle2);
		group.selectedToggleProperty().addListener(square2);
		group.selectedToggleProperty().addListener(ellipse2);
		group.selectedToggleProperty().addListener(circle2);
		group.selectedToggleProperty().addListener(dropper);
		group.selectedToggleProperty().addListener(mover2);
		group.selectedToggleProperty().addListener(eraser2);
		group.selectedToggleProperty().addListener(drect2);
		group.selectedToggleProperty().addListener(poly2);

		// Creates an action when the load button is pressed
		load.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {

				// Opens the FileChooser
				FileChooser fileChooser = new FileChooser();
				file = fileChooser.showOpenDialog(stage);

				// Prints the file path
				System.out.println(file);

				// Takes the file path and displays the image
				image1 = new Image("file:///" + file);
				// ImageView iv = new ImageView(image1);

				Canvas canvasL;
				if (image1 != null) {
					canvasI.setHeight(image1.getHeight());
					canvasI.setWidth(image1.getWidth());
					// canvasI = new Canvas(image1.getWidth(), image1.getHeight());
				} else {
					canvasL = new Canvas(700, 700);
				}
				
				// GraphicsContext graphicsContext = canvasI.getGraphicsContext2D();
				graphicsContext.drawImage(image1, 0, 0);

				// Creates scroll bars
				ScrollPane scrollPane = new ScrollPane();
				scrollPane.setVbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane.setHbarPolicy(ScrollBarPolicy.ALWAYS);

				// Adds the components together onto one scene
				scrollPane.setContent(canvasI);
				StackPane stack_pane2 = new StackPane(scrollPane);

				// Adds the image to the tab
				canvasL = new Canvas(image1.getWidth(), image1.getHeight());
				GraphicsContext graphicsContext2 = canvasI.getGraphicsContext2D();
				graphicsContext2.drawImage(image1, 0, 0);
				ScrollPane scrollPane2 = new ScrollPane();
				scrollPane2.setVbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane2.setHbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane2.setContent(canvasI);
				StackPane stack_pane3 = new StackPane(scrollPane2);			   	
				int current = 0;
				current = tabPane.getSelectionModel().getSelectedIndex();
				selectionModel.select(current);
				selectionModel.getSelectedItem().setContent(stack_pane3);
					
				
				// Create a scene
				Scene scene2 = new Scene(grid, 0, 0);

				// Sets and launches the scene
				stage.setScene(scene2);
				stage.show();

			}
		});

		// Creates an action when the help button is pressed
		help.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {

				// Creates the new window
				Stage sHelp = new Stage();
				sHelp.setTitle("Help");
				GridPane gridHelp = new GridPane();

				// Adds text
				helpT = new Label("This is the helpful box!\n"
						+ "The goal of this program is to draw pretty pictures!\n"
						+ "You can also import images and draw on them!\n"
						+ "The load button allows you to select the image (can use 'l') \n"
						+ "The save button saves your file (can use 's') \n"
						+ "The save as button saves your image as a new file (can use 'a') \n"
						+ "The help button allows you to draw (can use 'u') \n"
						+ "The close button exits the program (neatly) (can use 'n') \n"
						+ "The slider changes the thickness of your brush\n"
						+ "Kole's Pain(t) Version 0.4.0 -  9/21/2020 \n" + "New features: \n"
						+ "Ability to add text to the image \n" + "Eraser tool \n"
						+ "For more: C:\\Users\\koleb\\Desktop\\Kole_Johnson_Pain(t)_Sprint_4 \n" + "Enjoy pain(t)!");

				// Displays window
				gridHelp.add(helpT, 0, 0);
				Scene scene3 = new Scene(gridHelp, 400, 400);
				sHelp.setScene(scene3);
				sHelp.show();
			}
		});

		// Creates an action when the help button is pressed
		undo.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				image1 = stackUndo.pull();
				stackRedo.push(canvasI);

				Canvas canvasL;
				if (image1 != null) {
					canvasI.setHeight(image1.getHeight());
					canvasI.setWidth(image1.getWidth());
					// canvasI = new Canvas(image1.getWidth(), image1.getHeight());
				} else {
					canvasL = new Canvas(700, 700);
				}

				// GraphicsContext graphicsContext = canvasI.getGraphicsContext2D();
				graphicsContext.drawImage(image1, 0, 0);

				// Creates scroll bars
				ScrollPane scrollPane = new ScrollPane();
				scrollPane.setVbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane.setHbarPolicy(ScrollBarPolicy.ALWAYS);

				// Adds the components together onto one scene
				GraphicsContext graphicsContext2 = canvasI.getGraphicsContext2D();
				graphicsContext2.drawImage(image1, 0, 0);
				ScrollPane scrollPane2 = new ScrollPane();
				scrollPane2.setVbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane2.setHbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane2.setContent(canvasI);
				StackPane stack_pane3 = new StackPane(scrollPane2);			   	
				int current = 0;
				current = tabPane.getSelectionModel().getSelectedIndex();
				selectionModel.select(current);
				selectionModel.getSelectedItem().setContent(stack_pane3);

				// Create a scene
				Scene scene2 = new Scene(grid, 0, 0);

				// Sets and launches the scene
				stage.setScene(scene2);
				stage.show();
			}
		});

		// Creates an action when the help button is pressed
		redo.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				stackUndo.push(canvasI);
				image1 = stackRedo.pull();

				Canvas canvasL;
				if (image1 != null) {
					canvasI.setHeight(image1.getHeight());
					canvasI.setWidth(image1.getWidth());
					// canvasI = new Canvas(image1.getWidth(), image1.getHeight());
				} else {
					canvasL = new Canvas(700, 700);
				}

				// GraphicsContext graphicsContext = canvasI.getGraphicsContext2D();
				graphicsContext.drawImage(image1, 0, 0);

				// Creates scroll bars
				ScrollPane scrollPane = new ScrollPane();
				scrollPane.setVbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane.setHbarPolicy(ScrollBarPolicy.ALWAYS);

				// Adds the components together onto one scene
				GraphicsContext graphicsContext2 = canvasI.getGraphicsContext2D();
				graphicsContext2.drawImage(image1, 0, 0);
				ScrollPane scrollPane2 = new ScrollPane();
				scrollPane2.setVbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane2.setHbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane2.setContent(canvasI);
				StackPane stack_pane3 = new StackPane(scrollPane2);			   	
				int current = 0;
				current = tabPane.getSelectionModel().getSelectedIndex();
				selectionModel.select(current);
				selectionModel.getSelectedItem().setContent(stack_pane3);

				// Create a scene
				Scene scene2 = new Scene(grid, 0, 0);

				// Sets and launches the scene
				stage.setScene(scene2);
				stage.show();
			}
		});

		// Resizes image/canvas and makes it bigger
		zoomI.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {

				// Takes the file path and displays the image
				// image1 = new Image("file:///" + file);
				ImageView iv = new ImageView(image1);

				// Prints the file path
				System.out.println(file);

				Image image2 = new Image("file:///" + file, image1.getWidth() + size, image1.getHeight() + size, false,
						false);

				Canvas canvasL;
				if (image1 != null) {
					canvasI.setHeight(image1.getHeight() + 100);
					canvasI.setWidth(image1.getWidth() + 100);
					// Image image2 = new Image("file:///" + file, image1.getHeight() + 100,
					// image1.getWidth() + 100, false, false);
					iv.setFitHeight(image1.getHeight() + 100);
					iv.setFitWidth(image1.getWidth() + 100);
					// canvasI = new Canvas(image1.getWidth(), image1.getHeight());
				} else {
					canvasL = new Canvas(700, 700);
				}

				image1 = image2;

				GraphicsContext graphicsContext = canvasI.getGraphicsContext2D();
				graphicsContext.drawImage(image2, 0, 0);

				// Creates scroll bars
				ScrollPane scrollPane = new ScrollPane();
				scrollPane.setVbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane.setHbarPolicy(ScrollBarPolicy.ALWAYS);

				// Adds the components together onto one scene
				GraphicsContext graphicsContext2 = canvasI.getGraphicsContext2D();
				graphicsContext2.drawImage(image1, 0, 0);
				ScrollPane scrollPane2 = new ScrollPane();
				scrollPane2.setVbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane2.setHbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane2.setContent(canvasI);
				StackPane stack_pane3 = new StackPane(scrollPane2);			   	
				int current = 0;
				current = tabPane.getSelectionModel().getSelectedIndex();
				selectionModel.select(current);
				selectionModel.getSelectedItem().setContent(stack_pane3);

				// Create a scene
				Scene scene2 = new Scene(grid, 1, 1);

				// Sets and launches the scene
				stage.setScene(scene2);
				stage.show();
			}
		});

		// Resizes image/canvas and makes it smaller
		zoomO.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {

				// Takes the file path and displays the image
				// image1 = new Image("file:///" + file);
				ImageView iv = new ImageView(image1);

				// Prints the file path
				System.out.println(file);

				Image image2 = new Image("file:///" + file, image1.getWidth() - size, image1.getHeight() - size, false,
						false);

				Canvas canvasL;
				if (image1 != null) {
					canvasI.setHeight(image1.getHeight() - size);
					canvasI.setWidth(image1.getWidth() - size);
					// Image image2 = new Image("file:///" + file, image1.getHeight() + 100,
					// image1.getWidth() + 100, false, false);
					iv.setFitHeight(image1.getHeight() - size);
					iv.setFitWidth(image1.getWidth() - size);
					// canvasI = new Canvas(image1.getWidth(), image1.getHeight());
				} else {
					canvasL = new Canvas(size, size);
				}

				image1 = image2;

				GraphicsContext graphicsContext = canvasI.getGraphicsContext2D();
				graphicsContext.drawImage(image2, 0, 0);

				// Creates scroll bars
				ScrollPane scrollPane = new ScrollPane();
				scrollPane.setVbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane.setHbarPolicy(ScrollBarPolicy.ALWAYS);

				// Adds the components together onto one scene
				GraphicsContext graphicsContext2 = canvasI.getGraphicsContext2D();
				graphicsContext2.drawImage(image1, 0, 0);
				ScrollPane scrollPane2 = new ScrollPane();
				scrollPane2.setVbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane2.setHbarPolicy(ScrollBarPolicy.ALWAYS);
				scrollPane2.setContent(canvasI);
				StackPane stack_pane3 = new StackPane(scrollPane2);			   	
				int current = 0;
				current = tabPane.getSelectionModel().getSelectedIndex();
				selectionModel.select(current);
				selectionModel.getSelectedItem().setContent(stack_pane3);

				// Create a scene
				Scene scene2 = new Scene(grid, 1, 1);

				// Sets and launches the scene
				stage.setScene(scene2);
				stage.show();
			}
		});

		// Creates an action when the Save As button is pressed
		saveAs.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {

				// Creates the new window
				Stage sWarn = new Stage();
				sWarn.setTitle("Warning");
				GridPane gridWarn = new GridPane();

				// Adds text
				warn = new Label("WARNING!\n"
						+ "The user has the ability to save the file in multiple \n"
						+ "file types. Changing types from native or choosing a \n"
						+ "lower quaility type may result in data loss!\n");

				// Displays window
				gridWarn.add(warn, 0, 0);
				gridWarn.add(saveConfirm, 2, 1);
				gridWarn.add(saveCancel, 2, 3);
				Scene scene3 = new Scene(gridWarn, 400, 400);
				sWarn.setScene(scene3);
				sWarn.show();	
				
				

				saveConfirm.setOnAction(new EventHandler<ActionEvent>() {
					public void handle(ActionEvent e) {
						//Set extension filter
		                //FileChooser.ExtensionFilter extFilter = 
		                //        new FileChooser.ExtensionFilter("png files (*.png)", "*.png");
		                //fileChooser.getExtensionFilters().add(extFilter);
						
						// Opens the FileChooser
						FileChooser fileChooser = new FileChooser();
						fileChooser.setTitle("Save Image");
						
						// Adds the file type to the FileChooser
						fileChooser.getExtensionFilters().addAll(new ExtensionFilter("All Files", "*.*"));
						fileChooser.getExtensionFilters().addAll(new ExtensionFilter("JPG", "*.jpg"));
						fileChooser.getExtensionFilters().addAll(new ExtensionFilter("PNG", "*.png"));
						file = fileChooser.showSaveDialog(stage);

						// Saves the file if the file is not empty
						if (file != null) {
							try {
								//WritableImage im = canvasI.snapshot(new SnapshotParameters(), null);
								//ImageIO.write(SwingFXUtils.fromFXImage(im, null), "png", file);
								WritableImage writableImage = new WritableImage((int)canvasI.getWidth(), (int)canvasI.getHeight());
		                        canvasI.snapshot(null, writableImage);
		                        RenderedImage renderedImage = SwingFXUtils.fromFXImage(writableImage, null);
		                        ImageIO.write(renderedImage, "png", file);
								//WritableImage im = canvas.snapshot(null, null);
								//ImageIO.write(SwingFXUtils.fromFXImage(im, null), "png", file);
							} catch (IOException ex) {
								System.out.println(ex.getMessage());
							}
						}
					}
				});
				saveCancel.setOnAction(new EventHandler<ActionEvent>() {
					public void handle(ActionEvent e) {
						sWarn.hide();
						return;
					}
				});
			}
		});

		// Creates an action when the Save As button is pressed
		save.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				// Saves the file if the file is not empty
				if (file != null) {				
					
					try {
						WritableImage writableImage = new WritableImage((int) canvasI.getWidth(),
								(int) canvasI.getHeight());
						canvasI.snapshot(null, writableImage);
						RenderedImage renderedImage = SwingFXUtils.fromFXImage(writableImage, null);
						ImageIO.write(renderedImage, "png", file);
						// WritableImage im = canvas.snapshot(null, null);
						// ImageIO.write(SwingFXUtils.fromFXImage(im, null), "png", file);
					} catch (IOException ex) {
						System.out.println(ex.getMessage());
					}
					timer.cancel();
					Timer timer2 = new Timer();
					timer2.scheduleAtFixedRate(new TimerTask() {
				        @Override
				        public void run() {
				            Platform.runLater(() -> {
				            	if (onoff == 0) {
				        			WritableImage writableImage = new WritableImage((int)canvasI.getWidth(), (int)canvasI.getHeight());
				                    canvasI.snapshot(null, writableImage);
				                    RenderedImage renderedImage = SwingFXUtils.fromFXImage(writableImage, null);
				                    try {
				        				ImageIO.write(renderedImage, "png", file);
				        			} catch (IOException e) {
				        				// TODO Auto-generated catch block
				        				e.printStackTrace();
				        			}
				                    System.out.print("||saved?||");
				        		} else {
				        			System.out.print("||not saved?||");
				        			return;
				        		}
				            });
				        }
				    }, 1, 10000);
				}
			}
		});

		// Turns autosave on when on is pressed
		onA.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				onoff = 0;
				auto.setText("Autosave: on");
				System.out.print(onoff);
			}
		});

		// Turns autosave off when off is pressed
		offA.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				onoff = 1;
				auto.setText("Autosave: off");
				System.out.print(onoff);
			}
		});
		
		// Creates and starts timer
		timer.scheduleAtFixedRate(new TimerTask() {
	        @Override
	        public void run() {
	            Platform.runLater(() -> {
	            	if (onoff == 0) {
	        			WritableImage writableImage = new WritableImage((int)canvasI.getWidth(), (int)canvasI.getHeight());
	                    canvasI.snapshot(null, writableImage);
	                    RenderedImage renderedImage = SwingFXUtils.fromFXImage(writableImage, null);
	                    try {
	        				ImageIO.write(renderedImage, "png", file);
	        			} catch (IOException e) {
	        				e.printStackTrace();
	        			}
	                    System.out.print("saved?");
	        		} else {
	        			System.out.print("not saved?");
	        			return;
	        		}
	            });
	        }
	    }, 1, 10000);
		
		// Changes the value of c when the color chooser is used
		EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				Color c = cp.getValue();
			}
		};
		cp.setOnAction(event);

		// Closes the program when the close button is pressed
		close1.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				// Creates the new window
				Stage smart = new Stage();
				smart.setTitle("Smart Save");
				GridPane gridSmart = new GridPane();

				// Adds text
				smartL = new Label("Hold on!\n" + "Make sure you save anything you did!\n"
						+ "Close this window to continue working!\n"
						+ "The save button saves your file and the close button closes without saving!\n");

				// Displays window
				gridSmart.add(smartL, 1, 1);
				Scene scene3 = new Scene(gridSmart, 500, 500);
				gridSmart.add(doubleClose, 2, 0);
				gridSmart.add(doubleSave, 0, 0);
				smart.setScene(scene3);
				smart.show();

				// Saves after the prompt
				doubleSave.setOnAction(new EventHandler<ActionEvent>() {
					public void handle(ActionEvent e) {

						// Opens the FileChooser
						FileChooser fileChooser = new FileChooser();
						fileChooser.setTitle("Save Image");

						// Adds the file type to the FileChooser
						fileChooser.getExtensionFilters().addAll(new ExtensionFilter("All Files", "*.*"));
						fileChooser.getExtensionFilters().addAll(new ExtensionFilter("JPG", "*.jpg"));
						fileChooser.getExtensionFilters().addAll(new ExtensionFilter("PNG", "*.png"));
						file = fileChooser.showSaveDialog(stage);

						// Saves the file if the file is not empty
						if (file != null) {
							try {
								WritableImage im = canvas.snapshot(null, null);
								ImageIO.write(SwingFXUtils.fromFXImage(image1, null), "png", file);
							} catch (IOException ex) {
								System.out.println(ex.getMessage());
							}
						}
					}
				});

				// Closes after the prompt
				doubleClose.setOnAction(new EventHandler<ActionEvent>() {
					public void handle(ActionEvent e) {
						System.exit(0);
					}
				});
			}
		});

		// Creates, sets, and shows the scene
		StackPane stack_pane = new StackPane(grid);
		Scene scene = new Scene(stack_pane, 1820, 980);

		// Adds keybinds to menu buttons
		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				switch (event.getCode()) {
				case L:
					load.fire();
				case S:
					save.fire();
				case A:
					saveAs.fire();
				case H:
					help.fire();
				case C:
					close1.fire();
				case I:
					zoomI.fire();
				case O:
					zoomO.fire();
				case Q:
					break;
				default:
					break;
				}
			}
		});
		
		//timer.schedule(new autosave(canvasI, onoff, file), 0, 9000);

		// scene.getAccelerators().
		stage.setScene(scene);
		stage.show();

	}

	// Main that launches the program
	public static void main(String[] args) {
		launch();
	}

	private void draw(Canvas canvasI, Color color) {
		GraphicsContext g = canvasI.getGraphicsContext2D();
		g.setFill(Color.TRANSPARENT);
		g.fillRect(0, 0, canvasI.getWidth(), canvasI.getHeight());
		if (pointCt == 0)
			return;
		g.setLineWidth(2);
		g.setStroke(color);
		if (complete) { // draw a polygon
			g.setFill(color);
			g.fillPolygon(xCoord, yCoord, pointCt);
			g.strokePolygon(xCoord, yCoord, pointCt);
		} else { // show the lines the user has drawn so far
			g.setFill(color);
			g.fillRect(xCoord[0] - 2, yCoord[0] - 2, 6, 6); // small square marks first point
			for (int i = 0; i < pointCt - 1; i++) {
				g.strokeLine(xCoord[i], yCoord[i], xCoord[i + 1], yCoord[i + 1]);
			}
		}
	}
	
	/*private void newTab(String num, String name) {
		Tab num = new Tab(tName.getText(), new Label(""));
		tabPane.getTabs().add(tab);
		Canvas canvas = new Canvas(500, 500);
		tab.setContent(canvas);
	}*/
}